Documentation covering building and using the python binding for libtorrent
is located in the main doc directory. See docs/python_binding.html

